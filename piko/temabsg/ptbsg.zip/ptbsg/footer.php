
</main>
        <footer>
            <div style="background-color: #000;height: 50px;color:#FFF;">
                <p style="padding-top:15px;text-align: center"><?php _e( '© 2019 PT BSG All rights reserved', 'ptbsg' ); ?></p>
            </div>
        </footer>
        <!-- Bootstrap core JavaScript
    ================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <?php wp_footer(); ?>
    </body>
</html>
